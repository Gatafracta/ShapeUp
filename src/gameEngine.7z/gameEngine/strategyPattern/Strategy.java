/**
 * 
 */
package gameEngine.strategyPattern;

/**
 * @author ludov
 *
 */
interface Strategy {

}
