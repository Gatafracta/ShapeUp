/**
 * 
 */
package gameEngine.strategyPattern;

/**
 * @author ludov
 *
 */
public class Context {

}
