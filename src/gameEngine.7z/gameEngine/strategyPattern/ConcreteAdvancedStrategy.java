/**
 * 
 */
package gameEngine.strategyPattern;

/**
 * @author ludov
 *
 */
class ConcreteAdvancedStrategy implements Strategy {

}
