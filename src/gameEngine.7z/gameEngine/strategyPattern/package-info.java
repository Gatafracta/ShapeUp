/**
 * 
 */
/**
 * @author ludov
 *
 */
package gameEngine.strategyPattern;