/**
 * 
 */
package gameEngine.strategyPattern;

/**
 * @author ludov
 *
 */
class ConcreteDefaultStrategy implements Strategy {

}
