/**
 * 
 */
package gameEngine;

/**
 * @author ludov
 *
 */
class VirtualPlayer extends Player {

	VirtualPlayer(String name) {
		super(name);
	}

	@Override
	public void play() {
		// TODO Auto-generated method stub
		
	}

}
