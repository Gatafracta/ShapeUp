/**
 * 
 */
/**
 * @author ludov
 *
 */
package gameEngine.enumerate;