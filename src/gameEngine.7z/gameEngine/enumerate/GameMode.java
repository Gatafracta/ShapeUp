/**
 * 
 */
package gameEngine.enumerate;

/**
 * @author ludov
 *
 */
public enum GameMode {
	DEFAULT,
	ADVANCED,
	DRAWING
}
