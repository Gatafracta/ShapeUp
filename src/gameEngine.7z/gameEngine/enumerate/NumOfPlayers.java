/**
 * 
 */
package gameEngine.enumerate;

/**
 * @author ludov
 *
 */
public enum NumOfPlayers {
	TWO,
	THREE
}
