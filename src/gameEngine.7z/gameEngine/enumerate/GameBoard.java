/**
 * 
 */
package gameEngine.enumerate;

/**
 * @author ludov
 *
 */
public enum GameBoard {
	RECTANGLE,
	FIR,
	STAR
}
