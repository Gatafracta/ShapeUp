/**
 * 
 */
package gameEngine.scoreVisitorPattern;

/**
 * @author ludov
 *
 */
class CounterVisitorA implements CounterVisitorBase {

}
