/**
 * 
 */
package gameEngine.scoreVisitorPattern;

import gameEngine.GameBoard;

/**
 * @author ludov
 *
 */
class GameBoardRect extends GameBoard implements GameBoardCount {
	
}
