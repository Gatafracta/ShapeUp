/**
 * 
 */
package gameEngine.scoreVisitorPattern;

/**
 * @author ludov
 *
 */
interface CounterVisitorBase {

}
