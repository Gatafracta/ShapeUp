/**
 * 
 */
package gameEngine.scoreVisitorPattern;

/**
 * @author ludov
 *
 */
interface GameBoardCount {

}
