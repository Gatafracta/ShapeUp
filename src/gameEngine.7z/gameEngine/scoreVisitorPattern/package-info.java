/**
 * 
 */
/**
 * @author ludov
 *
 */
package gameEngine.scoreVisitorPattern;