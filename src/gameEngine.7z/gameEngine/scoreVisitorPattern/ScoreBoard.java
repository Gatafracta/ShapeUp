/**
 * 
 */
package gameEngine.scoreVisitorPattern;

/**
 * @author ludov
 *
 */
public class ScoreBoard {

}
